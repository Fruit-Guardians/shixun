# 零 AI 的云端同步

Google Apps Script 每 15 分钟扫描指定 Google Drive 文件夹，仅发送新增或更新的完整 Markdown。不会调用 Codex、ChatGPT 或其他模型，不依赖个人电脑开机。

## 一次性安装
1. 在拥有源文件夹读取权的 Google 账号中创建独立 Apps Script 项目。
2. 将 `Code.gs` 的内容粘贴到默认脚本文件。在项目设置勾选“在编辑器中显示 appsscript.json 清单文件”，再将本包的 `appsscript.json` 内容粘贴到清单。
3. 在项目设置 → 脚本属性中配置 `SITE_SERVICE_TOKEN`，值在拾讯站点「数据与同步」中点击“复制站点连接凭证”获取。凭证只保存在脚本属性，不写进脚本正文或执行日志。
4. 手动运行 `installSync`，在 Google 授权页核对只读 Drive、向外部服务发出请求及管理本项目触发器的权限。需要所有者本人完成授权。
5. 确认执行日志 `installed: true`，站点同步面板出现 Google Apps Script 的成功回读记录，再视为自动同步已启用。

源目录与站点地址已写入非敏感配置，保持站点 owner-private。这个方案使用 Google 账号的只读 Drive 权限，程序只枚举指定目录，不修改源文件。

运行 `disableSync` 可以撤销本项目的同步触发器；不会删除日报。

## 状态边界
源连接器可读不代表此脚本已获得授权；脚本文件准备好也不代表触发器已安装。实际授权、首次执行与触发器状态应分别核验。
